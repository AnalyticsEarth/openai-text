define(['./dist/openai-text'], (supernova) => supernova);
